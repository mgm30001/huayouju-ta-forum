import sqlite3
import MySQLdb
import os
from datetime import datetime

def get_sqlite_db():
    """获取SQLite数据库连接"""
    conn = sqlite3.connect('forum.db')
    conn.row_factory = sqlite3.Row
    return conn

def get_mysql_db():
    """获取MySQL数据库连接"""
    return MySQLdb.connect(
        host=os.environ.get('MYSQL_HOST', 'localhost'),
        user=os.environ.get('MYSQL_USER', 'root'),
        passwd=os.environ.get('MYSQL_PASSWORD', ''),
        db=os.environ.get('MYSQL_DATABASE', 'forum'),
        charset='utf8mb4'
    )

def migrate_data():
    """迁移数据从SQLite到MySQL"""
    sqlite_conn = get_sqlite_db()
    mysql_conn = get_mysql_db()
    
    sqlite_cur = sqlite_conn.cursor()
    mysql_cur = mysql_conn.cursor()
    
    # 迁移用户表
    print("迁移用户表...")
    sqlite_cur.execute('SELECT * FROM users')
    for row in sqlite_cur.fetchall():
        mysql_cur.execute('''
            INSERT INTO users (id, username, password, email, avatar, created_at, last_login, status)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        ''', (
            row['id'], row['username'], row['password'], row['email'],
            row['avatar'], row['created_at'], row['last_login'], row['status']
        ))
    
    # 迁移版块表
    print("迁移版块表...")
    sqlite_cur.execute('SELECT * FROM forums')
    for row in sqlite_cur.fetchall():
        mysql_cur.execute('''
            INSERT INTO forums (id, name, description, parent_id, order_num, created_at)
            VALUES (%s, %s, %s, %s, %s, %s)
        ''', (
            row['id'], row['name'], row['description'],
            row['parent_id'], row['order_num'], row['created_at']
        ))
    
    # 迁移主题表
    print("迁移主题表...")
    sqlite_cur.execute('SELECT * FROM topics')
    for row in sqlite_cur.fetchall():
        mysql_cur.execute('''
            INSERT INTO topics (id, forum_id, user_id, title, content, views, replies, created_at, updated_at, status)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        ''', (
            row['id'], row['forum_id'], row['user_id'], row['title'],
            row['content'], row['views'], row['replies'],
            row['created_at'], row['updated_at'], row['status']
        ))
    
    # 迁移回复表
    print("迁移回复表...")
    sqlite_cur.execute('SELECT * FROM replies')
    for row in sqlite_cur.fetchall():
        mysql_cur.execute('''
            INSERT INTO replies (id, topic_id, user_id, content, created_at, status)
            VALUES (%s, %s, %s, %s, %s, %s)
        ''', (
            row['id'], row['topic_id'], row['user_id'],
            row['content'], row['created_at'], row['status']
        ))
    
    # 迁移附件表
    print("迁移附件表...")
    sqlite_cur.execute('SELECT * FROM attachments')
    for row in sqlite_cur.fetchall():
        mysql_cur.execute('''
            INSERT INTO attachments (id, topic_id, reply_id, user_id, filename, filepath, filesize, created_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        ''', (
            row['id'], row['topic_id'], row['reply_id'], row['user_id'],
            row['filename'], row['filepath'], row['filesize'], row['created_at']
        ))
    
    # 提交更改
    mysql_conn.commit()
    
    # 关闭连接
    sqlite_conn.close()
    mysql_conn.close()
    
    print("数据迁移完成！")

if __name__ == '__main__':
    migrate_data() 