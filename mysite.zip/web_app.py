from flask import Flask, render_template, request, redirect, url_for, flash, session
import sqlite3
import MySQLdb
import MySQLdb.cursors
from datetime import datetime
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', os.urandom(24))

# 文件上传配置
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static', 'uploads')
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 限制文件大小为16MB

# 数据库配置
DB_TYPE = os.environ.get('DB_TYPE', 'sqlite')  # 默认使用sqlite

def get_db():
    """获取数据库连接"""
    if DB_TYPE == 'mysql':
        try:
            # MySQL连接
            conn = MySQLdb.connect(
                host=os.environ.get('MYSQL_HOST', 'localhost'),
                user=os.environ.get('MYSQL_USER', 'root'),
                passwd=os.environ.get('MYSQL_PASSWORD', ''),
                db=os.environ.get('MYSQL_DATABASE', 'forum'),
                charset='utf8mb4',
                cursorclass=MySQLdb.cursors.DictCursor
            )
            return conn
        except MySQLdb.Error as e:
            print(f"MySQL连接错误：{str(e)}")
            # 如果MySQL连接失败，回退到SQLite
            return get_sqlite_db()
    else:
        return get_sqlite_db()

def get_sqlite_db():
    """获取SQLite数据库连接"""
    conn = sqlite3.connect('forum.db', detect_types=sqlite3.PARSE_DECLTYPES|sqlite3.PARSE_COLNAMES)
    conn.row_factory = sqlite3.Row
    return conn

def init_mysql_db():
    """初始化MySQL数据库"""
    conn = get_db()
    cursor = conn.cursor()
    
    # 创建用户表
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) UNIQUE,
            password VARCHAR(255),
            email VARCHAR(100) UNIQUE,
            avatar VARCHAR(255),
            created_at DATETIME,
            last_login DATETIME,
            status TINYINT DEFAULT 1
        ) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
    ''')
    
    # 创建版块表
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS forums (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100),
            description TEXT,
            parent_id INT,
            order_num INT,
            created_at DATETIME,
            FOREIGN KEY (parent_id) REFERENCES forums(id)
        ) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
    ''')
    
    # 创建主题表
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS topics (
            id INT AUTO_INCREMENT PRIMARY KEY,
            forum_id INT,
            user_id INT,
            title VARCHAR(255),
            content TEXT,
            views INT DEFAULT 0,
            replies INT DEFAULT 0,
            created_at DATETIME,
            updated_at DATETIME,
            status TINYINT DEFAULT 1,
            FOREIGN KEY (forum_id) REFERENCES forums(id),
            FOREIGN KEY (user_id) REFERENCES users(id)
        ) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
    ''')
    
    # 创建回复表
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS replies (
            id INT AUTO_INCREMENT PRIMARY KEY,
            topic_id INT,
            user_id INT,
            content TEXT,
            created_at DATETIME,
            status TINYINT DEFAULT 1,
            FOREIGN KEY (topic_id) REFERENCES topics(id),
            FOREIGN KEY (user_id) REFERENCES users(id)
        ) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
    ''')
    
    # 创建附件表
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS attachments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            topic_id INT,
            reply_id INT,
            user_id INT,
            filename VARCHAR(255),
            filepath VARCHAR(255),
            filesize INT,
            created_at DATETIME,
            FOREIGN KEY (topic_id) REFERENCES topics(id),
            FOREIGN KEY (reply_id) REFERENCES replies(id),
            FOREIGN KEY (user_id) REFERENCES users(id)
        ) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
    ''')
    
    conn.commit()
    conn.close()

# 如果使用MySQL，初始化数据库表
if DB_TYPE == 'mysql':
    init_mysql_db()

def allowed_file(filename):
    """检查文件类型是否允许"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def save_file(file):
    """保存上传的文件"""
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        # 生成唯一文件名
        base, ext = os.path.splitext(filename)
        filename = f"{base}_{datetime.now().strftime('%Y%m%d%H%M%S')}{ext}"
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        try:
            file.save(file_path)
            return f"uploads/{filename}"  # 返回相对于static目录的路径
        except Exception as e:
            print(f"保存文件时出错: {str(e)}")
            return None
    return None

@app.template_filter('datetime')
def format_datetime(value, format='%Y-%m-%d %H:%M'):
    """格式化日期时间"""
    if isinstance(value, str):
        try:
            value = datetime.strptime(value, '%Y-%m-%d %H:%M:%S')
        except ValueError:
            return value
    return value.strftime(format) if value else ''

@app.route('/')
def index():
    """首页"""
    conn = get_db()
    cursor = conn.cursor()
    
    # 获取所有版块
    cursor.execute('SELECT * FROM forums ORDER BY order_num')
    forums = cursor.fetchall()
    
    # 获取最新主题
    cursor.execute('''
        SELECT t.*, f.name as forum_name, u.username as author_name
        FROM topics t
        JOIN forums f ON t.forum_id = f.id
        JOIN users u ON t.user_id = u.id
        ORDER BY t.created_at DESC
        LIMIT 10
    ''')
    latest_topics = cursor.fetchall()
    
    conn.close()
    return render_template('index.html', forums=forums, latest_topics=latest_topics)

@app.route('/forum/<int:forum_id>')
def forum(forum_id):
    """版块页面"""
    conn = get_db()
    cursor = conn.cursor()
    
    # 获取版块信息
    cursor.execute('SELECT * FROM forums WHERE id = ?', (forum_id,))
    forum = cursor.fetchone()
    
    if not forum:
        flash('版块不存在')
        return redirect(url_for('index'))
    
    # 获取版块下的主题
    cursor.execute('''
        SELECT t.*, u.username as author_name
        FROM topics t
        JOIN users u ON t.user_id = u.id
        WHERE t.forum_id = ?
        ORDER BY t.created_at DESC
    ''', (forum_id,))
    topics = cursor.fetchall()
    
    conn.close()
    return render_template('forum.html', forum=forum, topics=topics)

@app.route('/topic/<int:topic_id>')
def topic(topic_id):
    """主题页面"""
    conn = get_db()
    cursor = conn.cursor()
    
    # 获取主题信息
    cursor.execute('''
        SELECT t.*, f.name as forum_name, u.username as author_name
        FROM topics t
        JOIN forums f ON t.forum_id = f.id
        JOIN users u ON t.user_id = u.id
        WHERE t.id = ?
    ''', (topic_id,))
    topic = cursor.fetchone()
    
    if not topic:
        flash('主题不存在')
        return redirect(url_for('index'))
    
    # 获取回复
    cursor.execute('''
        SELECT r.*, u.username as author_name
        FROM replies r
        JOIN users u ON r.user_id = u.id
        WHERE r.topic_id = ?
        ORDER BY r.created_at ASC
    ''', (topic_id,))
    replies = cursor.fetchall()
    
    # 更新浏览次数
    cursor.execute('UPDATE topics SET views = views + 1 WHERE id = ?', (topic_id,))
    conn.commit()
    
    conn.close()
    return render_template('topic.html', topic=topic, replies=replies)

@app.route('/register', methods=['GET', 'POST'])
def register():
    """用户注册"""
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
        
        conn = get_db()
        cursor = conn.cursor()
        
        # 检查用户名是否已存在
        cursor.execute('SELECT id FROM users WHERE username = ?', (username,))
        if cursor.fetchone():
            flash('用户名已存在')
            return redirect(url_for('register'))
        
        # 检查邮箱是否已存在
        cursor.execute('SELECT id FROM users WHERE email = ?', (email,))
        if cursor.fetchone():
            flash('邮箱已被注册')
            return redirect(url_for('register'))
        
        # 创建新用户
        cursor.execute('''
            INSERT INTO users (username, password, email, created_at)
            VALUES (?, ?, ?, ?)
        ''', (username, password, email, datetime.now()))
        conn.commit()
        conn.close()
        
        flash('注册成功，请登录')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """用户登录"""
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = get_db()
        cursor = conn.cursor()
        
        # 验证用户
        cursor.execute('SELECT * FROM users WHERE username = ? AND password = ?', (username, password))
        user = cursor.fetchone()
        
        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            
            # 更新最后登录时间
            cursor.execute('UPDATE users SET last_login = ? WHERE id = ?', (datetime.now(), user['id']))
            conn.commit()
            conn.close()
            
            flash('登录成功')
            return redirect(url_for('index'))
        else:
            flash('用户名或密码错误')
            return redirect(url_for('login'))
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    """用户登出"""
    session.clear()
    flash('已登出')
    return redirect(url_for('index'))

@app.route('/new_topic/<int:forum_id>', methods=['GET', 'POST'])
def new_topic(forum_id):
    """发布新主题"""
    if 'user_id' not in session:
        flash('请先登录')
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']
        
        # 处理图片上传
        images = []
        if 'images' in request.files:
            files = request.files.getlist('images')
            for file in files:
                file_path = save_file(file)
                if file_path:
                    images.append(file_path)
        
        # 将图片路径添加到内容中
        if images:
            image_html = '\n'.join([f'<img src="/static/{img}" alt="上传的图片" style="max-width: 100%;">' for img in images])
            content = f"{content}\n\n{image_html}"
        
        conn = get_db()
        cursor = conn.cursor()
        
        # 创建新主题
        cursor.execute('''
            INSERT INTO topics (forum_id, user_id, title, content, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (forum_id, session['user_id'], title, content, datetime.now(), datetime.now()))
        topic_id = cursor.lastrowid
        
        # 保存图片信息到数据库
        for image_path in images:
            cursor.execute('''
                INSERT INTO attachments (topic_id, user_id, filepath, created_at)
                VALUES (?, ?, ?, ?)
            ''', (topic_id, session['user_id'], image_path, datetime.now()))
        
        conn.commit()
        conn.close()
        
        flash('主题发布成功')
        return redirect(url_for('topic', topic_id=topic_id))
    
    return render_template('new_topic.html', forum_id=forum_id)

@app.route('/reply/<int:topic_id>', methods=['POST'])
def reply(topic_id):
    """发表回复"""
    if 'user_id' not in session:
        flash('请先登录')
        return redirect(url_for('login'))
    
    content = request.form['content']
    
    # 处理图片上传
    images = []
    if 'images' in request.files:
        files = request.files.getlist('images')
        for file in files:
            file_path = save_file(file)
            if file_path:
                images.append(file_path)
    
    # 将图片路径添加到内容中
    if images:
        image_html = '\n'.join([f'<img src="/static/{img}" alt="上传的图片" style="max-width: 100%;">' for img in images])
        content = f"{content}\n\n{image_html}"
    
    conn = get_db()
    cursor = conn.cursor()
    
    # 创建回复
    cursor.execute('''
        INSERT INTO replies (topic_id, user_id, content, created_at)
        VALUES (?, ?, ?, ?)
    ''', (topic_id, session['user_id'], content, datetime.now()))
    reply_id = cursor.lastrowid
    
    # 保存图片信息到数据库
    for image_path in images:
        cursor.execute('''
            INSERT INTO attachments (topic_id, reply_id, user_id, filepath, created_at)
            VALUES (?, ?, ?, ?, ?)
        ''', (topic_id, reply_id, session['user_id'], image_path, datetime.now()))
    
    # 更新主题回复数
    cursor.execute('UPDATE topics SET replies = replies + 1 WHERE id = ?', (topic_id,))
    
    conn.commit()
    conn.close()
    
    flash('回复成功')
    return redirect(url_for('topic', topic_id=topic_id))

if __name__ == '__main__':
    app.run(debug=True) 